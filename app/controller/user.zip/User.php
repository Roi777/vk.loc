<?php
class User {

	public function index() {
		echo 'Hi our guest';
	}
	
		public function login() {
			echo 'Please your login';
		}
	}